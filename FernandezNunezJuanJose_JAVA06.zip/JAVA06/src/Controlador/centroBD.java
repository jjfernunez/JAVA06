/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Centro;
import Modelo.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alumno
 */
public class centroBD {
    private static Connection con = null;
   private static PreparedStatement stmt = null;
   private static ResultSet rset = null;
    
   public static ResultSet centroRset (Cliente cliente) throws MenError{
       try{
            con = Conexion.getConnection();
            
           String sql = "SELECT * FROM CENTRO WHERE IDCENTRO IN(SELECT IDCENTRO FROM CONTRATO WHERE IDCLIENTE = ?)";
            
            stmt = con.prepareStatement(sql,
                                        ResultSet.TYPE_SCROLL_INSENSITIVE,
                                        ResultSet.CONCUR_UPDATABLE);
        
            stmt.setInt(1, cliente.getIdCliente());
            
            
            rset = stmt.executeQuery();
            rset.next();
             
        
        
           return rset;
        
        
        }catch(Exception e){
            
          //  System.out.println("Error al obtener el cliente");
          MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
          
            
        }
        
    
       
   }
   
   
   public static ResultSet getRset(){
       return rset;
   }
   public static Centro primero() throws MenError{
        try {
                rset.first();
                
                Centro centro = new Centro(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
        
                return centro;
            
        } catch (SQLException e) {
           MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
        }
       
       
   }
    public static Centro ultimo() throws MenError{
        try {
            rset.last();
                
                Centro centro = new Centro(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
        
                return centro;
            
        } catch (SQLException e) {
            MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
        }
       
       
   }
   
   public static Centro avanzar() throws MenError{
        try {
                if(!rset.isLast()){
                rset.next();
                Centro centro = new Centro(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
        
                return centro;
                }else{
                    
                    return null;
                }
            
        } catch (SQLException e) {
            MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
        }
       
       
   }
   
    public static Centro retroceder() throws MenError{
    
        try {
            if(!rset.isFirst()){
                rset.previous();
                Centro centro = new Centro(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
        
                return centro;
            }else{
                    
                    return null;
                }
            
        } catch (SQLException e) {
            MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
        }
       
       
        
    
    }
    
    public static ArrayList getCentroLista(Cliente cliente) throws MenError{
        
        ResultSet rs = centroRset(cliente);
        
        ArrayList <Centro> centros = new ArrayList<Centro>();
        try {
            rs.first();
            while(!rs.isLast()){
                
                Centro centro = new Centro(rs.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
                centros.add(centro);
                rs.next();
            }
            Centro centro = new Centro(rs.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
            centros.add(centro);
        } catch (SQLException e) {
           MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
        }
        
        return centros;
        
        
    }
    
    public static String getCentro(int id) throws MenError{
    
        try {
            String sql = "SELECT NOMBRE FROM CENTRO WHERE IDCENTRO = ?";            
            PreparedStatement st = con.prepareStatement(sql);
        
            st.setInt(1, id);
            
            
            ResultSet rs = st.executeQuery();
               rs.next();
                String string = rs.getString(1);
        
                return string;
            
        } catch (SQLException e) {
           MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
        }
       
       
        
    
    }
    
    
    public static void modificar(Centro centro) throws MenError{
        
       try {
           String sql = "UPDATE CENTRO SET NOMBRE = ?, NUMERO = ?, CALLE = ?, LOCALIDAD = ?, PROVINCIA = ?, CODPOSTAL = ?, CENTRO_REFERENCIA = ? WHERE IDCENTRO = ?";

           stmt = con.prepareStatement(sql);
           
           stmt.setString(1, centro.getNombre());
           stmt.setInt(2, centro.getNumero());
           stmt.setString(3, centro.getCalle());
           stmt.setString(4, centro.getLocalidad());
           stmt.setString(5, centro.getProvincia());
           stmt.setInt(6, centro.getCodPostal());
           stmt.setInt(7, centro.getReferenciaId());
           stmt.setInt(8, centro.getIdCentro());
           stmt.executeUpdate();
           
       } catch (SQLException e) {
          MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
       }
        
        
    }
        
    public static void borrar(Centro centro) throws MenError{
        
         try {
           String sql = "DELETE FROM CENTRO WHERE IDCENTRO = ?";

           stmt = con.prepareStatement(sql);
           
           
           stmt.setInt(1, centro.getIdCentro());
          
           stmt.executeUpdate();
           
       } catch (SQLException e) {
          MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
       }
        
        
    }
    
    
}
