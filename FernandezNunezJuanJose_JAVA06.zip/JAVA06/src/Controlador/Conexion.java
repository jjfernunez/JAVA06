/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.*;

/**
 *
 * @author alumno
 */
public class Conexion {

    private static Connection con = null;

    public static void open() {
        try {
            Class.forName("com.mysql.jdbc.Driver");	
        } catch (ClassNotFoundException e) {
            new MenError(1);
            //System.out.println("ERROR: exception loading driver class");
        }
               
        String url = "jdbc:mysql://localhost:3306/java06";
        try {
            con = DriverManager.getConnection(url,"root","1234");
        } catch (SQLException ex) {
            new MenError(2);
            
        }
        
    }


    public static Connection getConnection() throws SQLException {
        return con;
    } 
    
    public static void close() {
        try {
            con.close();
        } catch (Exception ignored) {}
    } 
}
    

