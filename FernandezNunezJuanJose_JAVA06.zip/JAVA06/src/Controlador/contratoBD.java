/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Centro;
import Modelo.Cliente;
import Modelo.Detalles;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alumno
 */
public class contratoBD {
      private static Connection con = null;
   private static PreparedStatement stmt = null;
   private static ResultSet rset = null;
    
   public static ResultSet centroRset (Cliente cliente) throws MenError{
       try{
            con = Conexion.getConnection();
            
           String sql = "SELECT * FROM CENTRO WHERE IDCENTRO IN(SELECT IDCENTRO FROM CONTRATO WHERE IDCLIENTE = ?)";
            
            stmt = con.prepareStatement(sql,
                                        ResultSet.TYPE_SCROLL_INSENSITIVE,
                                        ResultSet.CONCUR_UPDATABLE);
        
            stmt.setInt(1, cliente.getIdCliente());
            
            
            rset = stmt.executeQuery();
            rset.next();
             
        
        
           return rset;
        
        
        }catch(Exception e){
            
          //  System.out.println("Error al obtener el cliente");
          MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
        
            
        }
        
    
       
   }
   
   
   public static ResultSet getRset(){
       return rset;
   }
   public static Centro primero() throws MenError{
        try {
                rset.first();
                
                Centro centro = new Centro(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
        
                return centro;
            
        } catch (SQLException ex) {
          MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
       
       
   }
    public static Centro ultimo() throws MenError{
        try {
            rset.last();
                
                Centro centro = new Centro(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
        
                return centro;
            
        } catch (SQLException ex) {
            MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
       
       
   }
   
   public static Centro avanzar() throws MenError{
        try {
                if(!rset.isLast()){
                rset.next();
                Centro centro = new Centro(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
        
                return centro;
                }else{
                    
                    return null;
                }
            
        } catch (SQLException ex) {
           MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
       
       
   }
   
    public static Centro retroceder() throws MenError{
    
        try {
            if(!rset.isFirst()){
                rset.previous();
                Centro centro = new Centro(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getInt(4), rset.getString(5), rset.getString(6), rset.getInt(7), rset.getInt(8));
        
                return centro;
            }else{
                    
                    return null;
                }
            
        } catch (SQLException ex) {
           MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
       
       
        
    
    }
    

}
