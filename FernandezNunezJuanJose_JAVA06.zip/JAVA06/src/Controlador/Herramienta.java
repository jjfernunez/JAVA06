/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

/**
 *
 * @author bosque
 */
public class Herramienta { 
  
    public static String gregorianCalendarToString(GregorianCalendar fecha){   
        try{
        SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
        return formatDate.format(fecha.getTime());        
        }catch(NullPointerException e){
            return null;
        }
    }    
    
    public static GregorianCalendar dateToGregorianCalendar(Date fecha){
        try{
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTime(fecha);
        return gc;
        }catch(NullPointerException e){
            return null;
        }
    }
    
    public static void mensaje(String error){
        JOptionPane.showMessageDialog(null, error, "ERROR", JOptionPane.ERROR_MESSAGE);
    }
     

}
