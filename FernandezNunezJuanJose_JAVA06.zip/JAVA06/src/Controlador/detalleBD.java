package Controlador;

import static Controlador.centroBD.centroRset;
import Modelo.Detalles;
import Modelo.Detalles;
import Modelo.Cliente;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class detalleBD {
      private static Connection con = null;
   private static PreparedStatement stmt = null;
   private static ResultSet rset = null;
    
   public static ResultSet detalleRset (Cliente cliente) throws MenError{
       try{
            con = Conexion.getConnection();
            
           String sql = "SELECT * FROM DETALLES WHERE IDFACTURA IN(SELECT IDFACTURA FROM FACTURA WHERE IDCLIENTE = ?)";
            
            stmt = con.prepareStatement(sql,
                                        ResultSet.TYPE_SCROLL_INSENSITIVE,
                                        ResultSet.CONCUR_UPDATABLE);
        
            stmt.setInt(1, cliente.getIdCliente());
            
            
            rset = stmt.executeQuery();
            rset.next();
             
        
        
           return rset;
        
        
        }catch(Exception e){
            
          //  System.out.println("Error al obtener el cliente");
          MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
            
        }
        
    
       
   }
   
   
   public static ResultSet getRset(){
       return rset;
   }
   public static Detalles primero() throws MenError{
        try {
                rset.first();
                
                Detalles detalles = new Detalles(rset.getInt(1), rset.getInt(2), rset.getFloat(3), rset.getInt(4), rset.getFloat(5), rset.getString(6), rset.getFloat(7), rset.getFloat(8));
        
                return detalles;
            
        } catch (SQLException ex) {
           MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
       
       
   }
    public static Detalles ultimo() throws MenError{
        try {
            rset.last();
                
                Detalles detalles = new Detalles(rset.getInt(1), rset.getInt(2), rset.getFloat(3), rset.getInt(4), rset.getFloat(5), rset.getString(6), rset.getFloat(7), rset.getFloat(8));
        
                return detalles;
            
        } catch (SQLException ex) {
            MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
       
      
   }
   
   public static Detalles avanzar() throws MenError{
        try {
                if(!rset.isLast()){
                rset.next();
                Detalles detalles = new Detalles(rset.getInt(1), rset.getInt(2), rset.getFloat(3), rset.getInt(4), rset.getFloat(5), rset.getString(6), rset.getFloat(7), rset.getFloat(8));
        
                return detalles;
                }else{
                    
                    return null;
                }
            
        } catch (SQLException ex) {
            MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
       
       
   }
   
    public static Detalles retroceder() throws MenError{
    
        try {
            if(!rset.isFirst()){
                rset.previous();
                Detalles detalles = new Detalles(rset.getInt(1), rset.getInt(2), rset.getFloat(3), rset.getInt(4), rset.getFloat(5), rset.getString(6), rset.getFloat(7), rset.getFloat(8));
        
                return detalles;
            }else{
                    
                    return null;
                }
            
        } catch (SQLException ex) {
            MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
       
      
        
    
    }
    
    public static ArrayList getListaDetalles(Cliente cliente) throws MenError{
         
        
        ArrayList <Detalles> centros = new ArrayList<Detalles>();
        try {
            rset.first();
            while(!rset.isLast()){
                
                Detalles detalles = new Detalles(rset.getInt(1), rset.getInt(2), rset.getFloat(3), rset.getInt(4), rset.getFloat(5), rset.getString(6), rset.getFloat(7), rset.getFloat(8));
                centros.add(detalles);
                rset.next();
            }
                Detalles detalles = new Detalles(rset.getInt(1), rset.getInt(2), rset.getFloat(3), rset.getInt(4), rset.getFloat(5), rset.getString(6), rset.getFloat(7), rset.getFloat(8));
            centros.add(detalles);
        } catch (SQLException ex) {
            MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
        
        return centros;
        
        
        
    }
    
     public static int numeroMovimiento() throws MenError{
        
        String sql = "SELECT MAX(IDMOVIMIENTOS) FROM DETALLES"; 
        try {
           stmt = con.prepareStatement(sql);
           
          
           
            ResultSet rs = stmt.executeQuery();
            
            rs.next();
            
           
           return rs.getInt(1) + 1;
           
       } catch (SQLException ex) {
           MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
       }
       
    }

    public static void nuevoDetalle(Detalles detalle) throws MenError {
       
         try {
           String sql = "INSERT INTO DETALLES VALUES (?,?,?,?,?,?,?,?)";

           PreparedStatement st = Conexion.getConnection().prepareStatement(sql);
           
           st.setInt(1, detalle.getIdMovimiento());
           st.setInt(2, detalle.getIdFactura());
           st.setFloat(3, detalle.getValorEuros());
           st.setInt(4, detalle.getValorPesetas());
           st.setFloat(5, detalle.getTipoIVA());
           st.setString(6, detalle.getTipoMoneda());
           st.setFloat(7, detalle.getValorMoneda());
           st.setFloat(8, detalle.getCambio());
           
           
           st.executeUpdate();
           
       } catch (SQLException e) {
          MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
       }
        
        
    }

    public static void cerrar() throws MenError{
          try {
              stmt.close();
              rset.close();
          } catch (SQLException ex) {
              MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
          }
        
    }

    public static void modificarDetalles(Detalles deta) throws MenError {
        
       String sql = "UPDATE DETALLES SET VALOR_EUROS = ?, VALOR_PESETAS = ?, TIPO_IVA = ?, TIPO_MONEDA = ?, VALOR_MONEDA = ?, TIPO_CAMBIO = ? WHERE IDMOVIMIENTOS = ?";
       
          try {
              stmt = con.prepareStatement(sql);
              stmt.setFloat(1, deta.getValorEuros());
              stmt.setInt(2, deta.getValorPesetas());
              stmt.setFloat(3, deta.getTipoIVA());
              stmt.setString(4, deta.getTipoMoneda());
              stmt.setFloat(5, deta.getValorMoneda());
              stmt.setFloat(6, deta.getCambio());
              stmt.setInt(7, deta.getIdMovimiento());
              stmt.executeUpdate();
             
          } catch (SQLException ex) {
             MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
          }


    }

    public static void borrar(Detalles detalles) throws MenError {
        
        String sql = "DELETE DETALLES WHERE IDMOVIMIENTOS = ?";
        
          try {
              stmt = con.prepareStatement(sql);
              stmt.setInt(1, detalles.getIdMovimiento());
              stmt.executeUpdate();
          } catch (SQLException ex) {
              MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
          }
        
        
        
    }
    
}

