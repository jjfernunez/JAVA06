/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;


import Modelo.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author alumno
 */
public class clienteBD {
   
   private static Connection con = null;
   private static PreparedStatement stmt = null;
   private static ResultSet rset = null;
    
    public static Cliente getCliente(String usuario, String contra) throws MenError{
    
        
        try{
            con = Conexion.getConnection();
            
           String sql = "SELECT * FROM CLIENTE WHERE USUARIO = ? AND CONTRA = ?";
            
            stmt = con.prepareStatement(sql);
        
            stmt.setString(1, usuario);
            stmt.setString(2, contra);
            
            rset = stmt.executeQuery();
            rset.next();
           
            Cliente cliente = new Cliente(rset.getInt(1), rset.getString(2), rset.getString(3), rset.getString(4), rset.getString(5), rset.getInt(6), rset.getString(7), rset.getString(8), rset.getInt(9), usuario, contra, rset.getString(12),rset.getFloat(13));
        
        
        
            return cliente;
        
        
        }catch(Exception e){
            
          //  System.out.println("Error al obtener el cliente");
          MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
            
        }
        
    
       
    
    }
    
     public static void actualizarDato(float dato, Cliente cliente) throws MenError{
        
       try {
           String sql = "UPDATE CLIENTE SET GASTOS = ? WHERE IdCliente = ?";

           stmt = con.prepareStatement(sql);
           
           stmt.setFloat(1, dato);
           stmt.setInt(2, cliente.getIdCliente());
           
           stmt.executeUpdate();
           
       } catch (SQLException e) {
           MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
       }
        
        
    }
     
     public static void modificarCliente(Cliente cliente) throws MenError{
        
       try {
                      String sql = "UPDATE CLIENTE SET IDCLIENTE = ?, NOMBRE = ?, EMPRESA = ?,CIF_NIF = ?,CALLE = ?,NUMERO = ?,LOCALIDAD = ?,PROVINCIA = ?,COD_POSTAL = ?,USUARIO = ?,CONTRA = ?,FOTO = ?, GASTOS = ? WHERE IdCliente = ?";

           stmt = con.prepareStatement(sql);
           
           stmt.setInt(1, cliente.getIdCliente());
           stmt.setString(2, cliente.getNombre());
           stmt.setString(3, cliente.getEmpresa());
           stmt.setString(4, cliente.getNif());
           stmt.setString(5, cliente.getCalle());
           stmt.setInt(6, cliente.getNumero());
           stmt.setString(7, cliente.getLocalidad());
           stmt.setString(8, cliente.getProvincia());
           stmt.setInt(9, cliente.getCodPostal());
           stmt.setString(10, cliente.getUsuario());
           stmt.setString(11, cliente.getContra());
           stmt.setString(12, cliente.getFoto());
           stmt.setFloat(13, cliente.getGastosTotales());
           
           stmt.executeUpdate();
           
       } catch (SQLException e) {
           MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
       }
        
        
    }
     
      public static void nuevoCliente(Cliente cliente) throws MenError{
        
       try {
                      String sql = "INSERT INTO CLIENTE VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,)";

           stmt = con.prepareStatement(sql);
           
           stmt.setInt(1, cliente.getIdCliente());
           stmt.setString(2, cliente.getNombre());
           stmt.setString(3, cliente.getEmpresa());
           stmt.setString(4, cliente.getNif());
           stmt.setString(5, cliente.getCalle());
           stmt.setInt(6, cliente.getNumero());
           stmt.setString(7, cliente.getLocalidad());
           stmt.setString(8, cliente.getProvincia());
           stmt.setInt(9, cliente.getCodPostal());
           stmt.setString(10, cliente.getUsuario());
           stmt.setString(11, cliente.getContra());
           stmt.setString(12, cliente.getFoto());
           stmt.setFloat(13, cliente.getGastosTotales());
           
           stmt.executeQuery();
           
       } catch (SQLException e) {
           MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
       }
        
        
    }

    public static void actualizarImagen(String image, Cliente cliente) throws MenError {
        
        String sql = "UPDATE CLIENTE SET FOTO = ? WHERE IDCLIENTE = ?";
        
       try {
           stmt = con.prepareStatement(sql);
           stmt.setString(1, image);
           stmt.setInt(2, cliente.getIdCliente());
           
           stmt.executeUpdate();
       } catch (SQLException ex) {
           MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
       }
        
    }
     
    public static float calcularDatos(Cliente cliente) throws MenError{
        
        String sql = "SELECT SUM(VALOR_EUROS) FROM DETALLES WHERE IDFACTURA IN(SELECT IDFACTURA FROM FACTURA WHERE IDCLIENTE = ?)"; 
        try {
           stmt = con.prepareStatement(sql);
           stmt.setInt(1, cliente.getIdCliente());
          
           
            ResultSet rs = stmt.executeQuery();
            
            rs.next();
            
           
           return rs.getFloat(1);
           
       } catch (SQLException ex) {
          MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
       }
        
    }
    
    public static int numeroCliente() throws MenError{
        
        String sql = "SELECT MAX(IDCLIENTE) FROM CLIENTE"; 
        try {
           stmt = con.prepareStatement(sql);
           
          
           
            ResultSet rs = stmt.executeQuery();
            
            rs.next();
            
           
           return rs.getInt(1) + 1;
           
       } catch (SQLException ex) {
          MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
         
         
       }
        
    }
     
}
