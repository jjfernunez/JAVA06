/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Factura;
import Modelo.Cliente;
import Modelo.Factura;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;

public class facturaBD {
      private static Connection con = null;
   private static PreparedStatement stmt = null;
   private static ResultSet rset = null;
    
   public static ResultSet facturaRset (Cliente cliente) throws MenError{
       try{
            con = Conexion.getConnection();
            
           String sql = "SELECT * FROM FACTURA WHERE IDCLIENTE = ?";
            
            stmt = con.prepareStatement(sql,
                                        ResultSet.TYPE_SCROLL_INSENSITIVE,
                                        ResultSet.CONCUR_UPDATABLE);
        
            stmt.setInt(1, cliente.getIdCliente());
            
            
            rset = stmt.executeQuery();
            rset.next();
             
        
        
           return rset;
        
        
        }catch(Exception e){
         MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
        }
   }
   
   
   public static ResultSet getRset(){
       return rset;
   }
   public static Factura primero() throws MenError{
        try {
                rset.first();
                
                Factura factura = null;
                if(rset.getDate(5) != null){
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), Herramienta.dateToGregorianCalendar(rset.getDate(5)));
                }
                else{
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), null);

                }
                return factura;
            
        } catch (SQLException ex) {
           MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
   }
    public static Factura ultimo() throws MenError{
        try {
            rset.last();
                
               Factura factura = null;
                if(rset.getDate(5) != null){
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), Herramienta.dateToGregorianCalendar(rset.getDate(5)));
                }
                else{
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), null);

                }
                return factura;
            
        } catch (SQLException ex) {
            MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
   }
   
   public static Factura avanzar() throws MenError{
        try {
                if(!rset.isLast()){
                rset.next();
               Factura factura = null;
                if(rset.getDate(5) != null){
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), Herramienta.dateToGregorianCalendar(rset.getDate(5)));
                }
                else{
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), null);

                }
                return factura;
                }else{
                    
                    return null;
                }
            
        } catch (SQLException ex) {
            MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
   }
   
    public static Factura retroceder() throws MenError{
    
        try {
            if(!rset.isFirst()){
                rset.previous();
               Factura factura = null;
                if(rset.getDate(5) != null){
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), Herramienta.dateToGregorianCalendar(rset.getDate(5)));
                }
                else{
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), null);

                }
                return factura;
            }else{
                    
                    return null;
                }
            
        } catch (SQLException ex) {
            MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
       
       
        
    
    }
    
    public static ArrayList getListaFactura(Cliente cliente) throws MenError{
         
        
        ArrayList <Factura> centros = new ArrayList<Factura>();
        try {
            rset.first();
            Factura factura = null;
            while(!rset.isLast()){
                
                if(rset.getDate(5) != null){
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), Herramienta.dateToGregorianCalendar(rset.getDate(5)));
                }
                else{
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), null);

                }               
                centros.add(factura);
                rset.next();
            }
                
                if(rset.getDate(5) != null){
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), Herramienta.dateToGregorianCalendar(rset.getDate(5)));
                }
                else{
                    factura = new Factura(rset.getInt(1), rset.getInt(2), Herramienta.dateToGregorianCalendar(rset.getDate(3)), rset.getString(4), null);

                }
                centros.add(factura);
        } catch (SQLException ex) {
            MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
        }
        
        return centros;
        
        
        
    }
     public static int numeroFactura() throws MenError{
        
        String sql = "SELECT MAX(IDFACTURA) FROM FACTURA"; 
        try {
           stmt = con.prepareStatement(sql);
           
          
           
            ResultSet rs = stmt.executeQuery();
            
            rs.next();
            
           
           return rs.getInt(1) + 1;
           
       } catch (SQLException ex) {
          MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
       }
        
    }

    public static void nuevaFactura(Factura factura) throws MenError {
        
        try {
           String sql = "INSERT INTO FACTURA VALUES (?,?,?,?,?)";

           stmt = con.prepareStatement(sql);
           
           stmt.setInt(1, factura.getIdFactura());
           stmt.setInt(2, factura.getIdCliente());
           stmt.setString(3, ""+factura.getFechaEmision().get(Calendar.YEAR)+"-"+factura.getFechaEmision().get(Calendar.MONTH)+"-"+factura.getFechaEmision().get(Calendar.DAY_OF_MONTH));
           stmt.setString(4, factura.getConcepto());
           stmt.setString(5, null);
          
           
           stmt.executeUpdate();
           
       } catch (SQLException e) {
          MenError err = new MenError(4);
          
          MenError.registrarError(e.getMessage());
          
         throw err;
       }   
    }
    
    public static void cerrar() throws MenError{
          try {
              stmt.close();
              rset.close();
          } catch (SQLException ex) {
             MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
          }
        
    }

    public static void modificarFactura(Factura fact) throws MenError {
        String sql = "UPDATE FACTURA SET CONCEPTO = ?, FECHA_PAGO = ? WHERE IDFACTURA = ?";
       
          try {
              stmt = con.prepareStatement(sql);
              stmt.setString(1, fact.getConcepto());
              
              if(fact.getFechaPago()!= null)
                stmt.setString(2, Herramienta.gregorianCalendarToString(fact.getFechaPago()));
              else
                stmt.setString(2, null);
              
              stmt.setInt(3, fact.getIdFactura());
              stmt.executeUpdate();
          } catch (SQLException ex) {
             MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
          }
        
        }

    public static void borrar(Factura factura) throws MenError {
        String sql = "DELETE FACTURA WHERE IDFACTURA = ?";
        
          try {
              stmt = con.prepareStatement(sql);
              stmt.setInt(1, factura.getIdFactura());
              stmt.executeUpdate();
          } catch (SQLException ex) {
              MenError err = new MenError(4);
          
          MenError.registrarError(ex.getMessage());
          
         throw err;
          }
            }
}
