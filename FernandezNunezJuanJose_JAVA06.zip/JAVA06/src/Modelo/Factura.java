/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.GregorianCalendar;

/**
 *
 * @author alumno
 */
public class Factura {
    
    private int idFactura;
    private int idCliente;
    private GregorianCalendar fechaEmision;
    private String concepto;
    private GregorianCalendar fechaPago;
  

 
    public Factura(int idFactura, int idCliente, GregorianCalendar fechaEmision, String concepto, GregorianCalendar fechaPago) {
        this.idFactura = idFactura;
        this.idCliente = idCliente;
        this.fechaEmision = fechaEmision;
        this.concepto = concepto;
        this.fechaPago = fechaPago;
        
    }
     public int getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(int idFactura) {
        this.idFactura = idFactura;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public GregorianCalendar getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(GregorianCalendar fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public GregorianCalendar getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(GregorianCalendar fechaPago) {
        this.fechaPago = fechaPago;
    }

 
    
}
