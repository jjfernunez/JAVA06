/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Controlador.MenError;
import Controlador.centroBD;

/**
 *
 * @author alumno
 */
public class Centro {
    
    private int idCentro;
    private String nombre;
     private String calle;
    private int numero;
    private String localidad;
    private String provincia;
    private String direccion;
    private int codPostal;
    private int centroReferencia;

  
     
    
    public Centro(int idCentro, String nombre, String calle, int numero, String localidad, String provincia, int codPostal, int centroReferencia) {
        this.idCentro = idCentro;
        this.nombre = nombre;
        this.calle = calle;
        this.numero = numero;
        this.localidad = localidad;
        this.provincia = provincia;
        this.direccion = construirDirec(calle, numero,localidad, provincia);
        this.codPostal = codPostal;
        this.centroReferencia = centroReferencia;
    }

    public String construirDirec(String calle, int numero, String localidad, String provincia){
        
        return "C/"+calle+", "+numero+", "+localidad+", "+provincia;
        
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }
    
    public int getIdCentro() {
        return idCentro;
    }

    public void setIdCentro(int idCentro) {
        this.idCentro = idCentro;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getCodPostal() {
        return codPostal;
    }

    public void setCodPostal(int codPostal) {
        this.codPostal = codPostal;
    }

    public int getReferenciaId(){
        return centroReferencia;
    }
    public String getCentroReferencia(int id) throws MenError {
        
      
        
        return centroBD.getCentro(id);
    }

    public void setCentroReferencia(int centroReferencia) {
        this.centroReferencia = centroReferencia;
    }
    
    
      @Override
    public String toString() {
        return "Centro: " + "idCentro=" + idCentro + ", nombre=" + nombre + ", direccion=" + direccion + ", codPostal=" + codPostal + ", centroReferencia=" + centroReferencia ;
    }

    
}
