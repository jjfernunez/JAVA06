/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.GregorianCalendar;

/**
 *
 * @author alumno
 */
public class Contrato {
    private int numContrato;
    private int idCliente;
    private int idCentro;
    private String empleadoEncargado;
    private String numeroExpediente;
    private String empresaEncargada;
    private String observaciones;
    private float tipoIVA;
    private float valorSinIva;
    private float valorFinal;
    private GregorianCalendar fecha;
    private String objeto;

     public Contrato(int numContrato, int idCliente, int idCentro, String empleadoEncargado, String numeroExpediente, String empresaEncargada, String observaciones, float tipoIVA, float valorSinIva, float valorFinal, GregorianCalendar fecha, String objeto) {
        this.numContrato = numContrato;
        this.idCliente = idCliente;
        this.idCentro = idCentro;
        this.empleadoEncargado = empleadoEncargado;
        this.numeroExpediente = numeroExpediente;
        this.empresaEncargada = empresaEncargada;
        this.observaciones = observaciones;
        this.tipoIVA = tipoIVA;
        this.valorSinIva = valorSinIva;
        this.valorFinal = valorFinal;
        this.fecha = fecha;
        this.objeto = objeto;
    }
    
    public void setNumContrato(int numContrato) {
        this.numContrato = numContrato;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public void setIdCentro(int idCentro) {
        this.idCentro = idCentro;
    }

    public void setEmpleadoEncargado(String empleadoEncargado) {
        this.empleadoEncargado = empleadoEncargado;
    }

    public void setNumeroExpediente(String numeroExpediente) {
        this.numeroExpediente = numeroExpediente;
    }

    public void setEmpresaEncargada(String empresaEncargada) {
        this.empresaEncargada = empresaEncargada;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public void setTipoIVA(float tipoIVA) {
        this.tipoIVA = tipoIVA;
    }

    public void setValorSinIva(float valorSinIva) {
        this.valorSinIva = valorSinIva;
    }

    public void setValorFinal(float valorFinal) {
        this.valorFinal = valorFinal;
    }

    public void setFecha(GregorianCalendar fecha) {
        this.fecha = fecha;
    }

    public void setObjeto(String objeto) {
        this.objeto = objeto;
    }

    public int getNumContrato() {
        return numContrato;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public int getIdCentro() {
        return idCentro;
    }

    public String getEmpleadoEncargado() {
        return empleadoEncargado;
    }

    public String getNumeroExpediente() {
        return numeroExpediente;
    }

    public String getEmpresaEncargada() {
        return empresaEncargada;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public float getTipoIVA() {
        return tipoIVA;
    }

    public float getValorSinIva() {
        return valorSinIva;
    }

    public float getValorFinal() {
        return valorFinal;
    }

    public GregorianCalendar getFecha() {
        return fecha;
    }

    public String getObjeto() {
        return objeto;
    }

   
    
}
