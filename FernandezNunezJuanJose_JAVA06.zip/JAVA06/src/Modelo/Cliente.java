/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author alumno
 */
public class Cliente {

   

    private int idCliente;
    private String nombre;
    private String empresa;
    private String nif;
    private String direccion;
    private String calle;
    private int numero;
    private String localidad;
    private String provincia;
    private int codPostal;
    private String usuario;
    private String contra;
    private String foto;
    private float gastosTotales;
    
    public Cliente(int idCliente, String nombre, String empresa, String nif, String calle, int numero, String localidad, String provincia, int codPostal, String usuario, String contra, String foto, float gastosTotal) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.empresa = empresa;
        this.nif = nif;
        this.calle = calle;
        this.numero = numero;
        this.localidad = localidad;
        this.provincia = provincia;
        this.direccion = construirDirec(calle,numero,localidad,provincia);
        this.codPostal = codPostal;
        this.usuario = usuario;
        this.contra = contra;
        this.foto = foto;
        this.gastosTotales = gastosTotal;
    }
    
    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String construirDirec(String calle, int numero, String localidad, String provincia){
        
        return "C/"+calle+", "+numero+", "+localidad+", "+provincia;
        
    }

    /**
     * @return the idCliente
     */
    public int getIdCliente() {
        return idCliente;
    }

    /**
     * @param idCliente the idCliente to set
     */
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the empresa
     */
    public String getEmpresa() {
        return empresa;
    }

    /**
     * @param empresa the empresa to set
     */
    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    /**
     * @return the nif
     */
    public String getNif() {
        return nif;
    }

    /**
     * @param nif the nif to set
     */
    public void setNif(String nif) {
        this.nif = nif;
    }

    /**
     * @return the direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @param direccion the direccion to set
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return the codPostal
     */
    public int getCodPostal() {
        return codPostal;
    }

    /**
     * @param codPostal the codPostal to set
     */
    public void setCodPostal(int codPostal) {
        this.codPostal = codPostal;
    }

    /**
     * @return the usuario
     */
    public String getUsuario() {
        return usuario;
    }

    /**
     * @param usuario the usuario to set
     */
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    /**
     * @return the contra
     */
    public String getContra() {
        return contra;
    }

    /**
     * @param contra the contra to set
     */
    public void setContra(String contra) {
        this.contra = contra;
    }

    /**
     * @return the foto
     */
    public String getFoto() {
        return "imagenes/"+foto;
    }

    /**
     * @param foto the foto to set
     */
    public void setFoto(String foto) {
        this.foto = foto;
    }

    /**
     * @return the gastosTotales
     */
    public float getGastosTotales() {
        return gastosTotales;
    }

    /**
     * @param gastosTotales the gastosTotales to set
     */
    public void setGastosTotales(float gastosTotales) {
        this.gastosTotales = gastosTotales;
    }
    
}
