/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author alumno
 */
public class Detalles {
    private int idMovimiento;
    private int idFactura;
    private float valorEuros;
    private int valorPesetas;
    private float tipoIVA;
    private String tipoMoneda;
    private float valorMoneda;
    private float cambio;

    public Detalles(int idMovimiento, int idFactura, float valorEuros, int valorPesetas, float tipoIVA, String tipoMoneda, float valorMoneda, float cambio) {
        this.idMovimiento = idMovimiento;
        this.idFactura = idFactura;
        this.valorEuros = valorEuros;
        this.valorPesetas = valorPesetas;
        this.tipoIVA = tipoIVA;
        this.tipoMoneda = tipoMoneda;
        this.valorMoneda = valorMoneda;
        this.cambio = cambio;
    }

    /**
     * @return the idMovimiento
     */
    public int getIdMovimiento() {
        return idMovimiento;
    }

    /**
     * @param idMovimiento the idMovimiento to set
     */
    public void setIdMovimiento(int idMovimiento) {
        this.idMovimiento = idMovimiento;
    }

    /**
     * @return the idFactura
     */
    public int getIdFactura() {
        return idFactura;
    }

    /**
     * @param idFactura the idFactura to set
     */
    public void setIdFactura(int idFactura) {
        this.idFactura = idFactura;
    }

    /**
     * @return the valorEuros
     */
    public float getValorEuros() {
        return valorEuros;
    }

    /**
     * @param valorEuros the valorEuros to set
     */
    public void setValorEuros(float valorEuros) {
        this.valorEuros = valorEuros;
    }

    /**
     * @return the valorPesetas
     */
    public int getValorPesetas() {
        return valorPesetas;
    }

    /**
     * @param valorPesetas the valorPesetas to set
     */
    public void setValorPesetas(int valorPesetas) {
        this.valorPesetas = valorPesetas;
    }

    /**
     * @return the tipoIVA
     */
    public float getTipoIVA() {
        return tipoIVA;
    }

    /**
     * @param tipoIVA the tipoIVA to set
     */
    public void setTipoIVA(float tipoIVA) {
        this.tipoIVA = tipoIVA;
    }

    /**
     * @return the tipoMoneda
     */
    public String getTipoMoneda() {
        return tipoMoneda;
    }

    /**
     * @param tipoMoneda the tipoMoneda to set
     */
    public void setTipoMoneda(String tipoMoneda) {
        this.tipoMoneda = tipoMoneda;
    }

    /**
     * @return the valorMoneda
     */
    public float getValorMoneda() {
        return valorMoneda;
    }

    /**
     * @param valorMoneda the valorMoneda to set
     */
    public void setValorMoneda(float valorMoneda) {
        this.valorMoneda = valorMoneda;
    }

    /**
     * @return the cambio
     */
    public float getCambio() {
        return cambio;
    }

    /**
     * @param cambio the cambio to set
     */
    public void setCambio(float cambio) {
        this.cambio = cambio;
    }
    
    
    
}
