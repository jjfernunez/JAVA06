CREATE TABLE DETALLES (IdMovimientos INT NOT NULL, IdFactura INT NOT NULL, Valor_euros DEC ( 10,2 ) NOT NULL,Valor_pesetas INT,Tipo_IVA DEC ( 3, 1 ) NOT NULL,Tipo_moneda VARCHAR ( 10 ),Valor_moneda DEC ( 3, 1 ),Tipo_cambio DEC ( 3, 1 ),CONSTRAINT PK_DETALLES6 PRIMARY KEY (IdFactura, IdMovimientos));

CREATE TABLE CONTRATO (numContrato INT NOT NULL,IdCliente INT NOT NULL,IdCentro INT NOT NULL,Empleado_encargado VARCHAR ( 30 ),Numero_expediente VARCHAR ( 15 ),Empresa_encargada VARCHAR ( 20 ) NOT NULL,Observaciones VARCHAR ( 500 ),Tipo_IVA DEC ( 3, 2 ) NOT NULL,Valor_sin_IVA DEC ( 10, 2 ) NOT NULL,Valor_final DEC ( 10, 2 ) NOT NULL,Fecha DATE NOT NULL,Objeto VARCHAR ( 500 ), CONSTRAINT PK_CONTRATO7 PRIMARY KEY (numContrato));
                                                                                                                                                     
CREATE TABLE FACTURA (IdFactura INT NOT NULL,IdCliente INT NOT NULL,Fecha DATE,Concepto VARCHAR ( 500 ),Fecha_pago VARCHAR ( 500 ),CONSTRAINT PK_FACTURA5 PRIMARY KEY (IdFactura));

CREATE TABLE CLIENTE (IdCliente INT NOT NULL,Nombre VARCHAR ( 50 ),Empresa VARCHAR ( 50 ),CIF_NIF VARCHAR ( 9 ) NOT NULL,Calle VARCHAR ( 50 ),Numero INT,Localidad VARCHAR ( 20 ),Provincia VARCHAR ( 20 ),Cod_Postal INT NOT NULL, usuario VARCHAR(20), contra VARCHAR(20), Foto VARCHAR(20), Gastos DEC(12,2), CONSTRAINT PK_CLIENTE0 PRIMARY KEY (IdCliente));

CREATE TABLE CENTRO (IdCentro INT NOT NULL,Nombre VARCHAR ( 50 ),Calle VARCHAR ( 50 ),Numero INT,Localidad VARCHAR ( 10 ),Provincia VARCHAR ( 10 ),codPostal INT, Centro_referencia INT NOT NULL, CONSTRAINT PK_CENTRO2 PRIMARY KEY (IdCentro));





INSERT INTO CENTRO VALUES(1,'Hospital Virgen del Loreto','Avda. de la Constituci�n',18,'Sevilla','Sevilla',41001, 3);
INSERT INTO CENTRO VALUES(2,'Hospital Santa Lucia','Ronda Norte',NULL,'Huelva','Huelva',21005, 3);
INSERT INTO CENTRO VALUES(3,'Centro de salud Maria auxiliadora','Avda. Ana de Viya',21,'Cadiz','Cadiz',11009,2);
INSERT INTO CENTRO VALUES(4,'Hospital Virgen de las Nieves','AV. DR. OL�RIZ',16,'Granada','Granada',18012,2);
INSERT INTO CENTRO VALUES(5,'Hospital Virgen de la Victoria','Campus Universitario',NULL,'Malaga','Malaga',29010,2);
INSERT INTO CENTRO VALUES(6,'Hospital Virgen del Loreto','Avda. de la Constituci�n',18,'Sevilla','Sevilla',41001, 3);
INSERT INTO CENTRO VALUES(7,'Hospital Santa Lucia','Ronda Norte',NULL,'Huelva','Huelva',21005, 3);
INSERT INTO CENTRO VALUES(8,'Centro de salud Maria auxiliadora','Avda. Ana de Viya',21,'Cadiz','Cadiz',11009,2);
INSERT INTO CENTRO VALUES(9,'Hospital Virgen de las Nieves','AV. DR. OL�RIZ',16,'Granada','Granada',18012,2);
INSERT INTO CENTRO VALUES(10,'Hospital Virgen de la Victoria','Campus Universitario',NULL,'Malaga','Malaga',29010,2);
INSERT INTO CENTRO VALUES(11,'Hospital Virgen del Loreto','Avda. de la Constituci�n',18,'Sevilla','Sevilla',41001, 3);
INSERT INTO CENTRO VALUES(12,'Hospital Santa Lucia','Ronda Norte',NULL,'Huelva','Huelva',21005, 3);
INSERT INTO CENTRO VALUES(13,'Centro de salud Maria auxiliadora','Avda. Ana de Viya',21,'Cadiz','Cadiz',11009,2);
INSERT INTO CENTRO VALUES(14,'Hospital Virgen de las Nieves','AV. DR. OL�RIZ',16,'Granada','Granada',18012,2);
INSERT INTO CENTRO VALUES(15,'Hospital Virgen de la Victoria','Campus Universitario',NULL,'Malaga','Malaga',29010,2);
INSERT INTO CENTRO VALUES(16,'Hospital Virgen del Loreto','Avda. de la Constituci�n',18,'Sevilla','Sevilla',41001, 3);
INSERT INTO CENTRO VALUES(17,'Hospital Santa Lucia','Ronda Norte',NULL,'Huelva','Huelva',21005, 3);
INSERT INTO CENTRO VALUES(18,'Centro de salud Maria auxiliadora','Avda. Ana de Viya',21,'Cadiz','Cadiz',11009,2);
INSERT INTO CENTRO VALUES(19,'Hospital Virgen de las Nieves','AV. DR. OL�RIZ',16,'Granada','Granada',18012,2);
INSERT INTO CENTRO VALUES(20,'Hospital Virgen de la Victoria','Campus Universitario',NULL,'Malaga','Malaga',29010,2);
INSERT INTO CENTRO VALUES(21,'Hospital Virgen del Loreto','Avda. de la Constituci�n',18,'Sevilla','Sevilla',41001, 3);
INSERT INTO CENTRO VALUES(22,'Hospital Santa Lucia','Ronda Norte',NULL,'Huelva','Huelva',21005, 3);
INSERT INTO CENTRO VALUES(23,'Centro de salud Maria auxiliadora','Avda. Ana de Viya',21,'Cadiz','Cadiz',11009,2);
INSERT INTO CENTRO VALUES(24,'Hospital Virgen de las Nieves','AV. DR. OL�RIZ',16,'Granada','Granada',18012,2);
INSERT INTO CENTRO VALUES(25,'Hospital Virgen de la Victoria','Campus Universitario',NULL,'Malaga','Malaga',29010,2);




INSERT INTO CLIENTE VALUES(1, 'SERVICIO ANDALUZ DE SALUD', 'Hospital Virgen del Loreto', 'Q9150013B', 'Avda. de la Constitucion', 18, 'Sevilla', 'Sevilla', 41001,'sas','sas', 'sas.jpg',0);
INSERT INTO CLIENTE VALUES(2, 'SERVICIOS DE EMERGENCIA NACIONAL', 'Hospital Santa Lucia', 'E2632533C', 'Ronda Norte',NULL,  'Huelva', 'Huelva', 21005,'sen','sen','sen.png',0);
INSERT INTO CLIENTE VALUES(3, 'ADESLAS', 'Centro de salud Maria auxiliadora', 'G6486542R', 'Avda. Ana de Viya', 21, 'C�diz', 'C�diz', 11009,'adeslas','adeslas','adeslas.png',0);
INSERT INTO CLIENTE VALUES(4, 'SANITAS', 'Hospital Virgen de las Nieves', 'D5486526H' ,'AV. DR. OLORIZ', 16, 'Granada', 'Granada', 18012,'sanitas','sanitas', 'sanitas.png',0);
INSERT INTO CLIENTE VALUES(5, 'VITHAS', 'Hospital Virgen de la Victoria', 'M8775121L', 'Campus Universitario',NULL,  'Malaga', 'Malaga', 29010,'vithas','vithas','Vithas.jpg',0);

INSERT INTO CONTRATO VALUES(1,1,1,'Kike Pelado Rodriguez','102153','ARQSevilla','Tener en cuenta la segunda parte del contrato',0.16,2494.20 ,2893.27 ,'3/4/1998',NULL);
INSERT INTO CONTRATO VALUES(2,2,2,'Juan Alberto Nu�ez Perejon','HS01078/01','ARQSevilla',NULL,0.16,10337.41 ,11991.39 ,'11/26/2001','COLABORACION PARA LA REDACCION Y EJECUCION DEL FUTURO CONVENIO URBANISTICO ENTRE IMPROASA Y EL EXCMO. AYUNTAMIENTO DE ARAHAL');
INSERT INTO CONTRATO VALUES(3,3,3,'Marcos de la Rosa Vizcaino','CC0034/98','ARQSevilla','A revisar la nueva edicion del convenio',0.16,7976.29 ,9252.50 ,'6/1/2004',NULL);
INSERT INTO CONTRATO VALUES(4,4,4,'Kike Pelado Rodriguez','CM 244/98','ARQSevilla',NULL,0.16,10336.37 ,11990.19 ,'3/21/2005','REDACCION DE PROYECTO HOSPITAL CAMPUS DE LA SALUD DE GRANADA');
INSERT INTO CONTRATO VALUES(5,5,5,'Kike Pelado Rodriguez','CM 169/98','ARQSevilla','SE RESCINDE EL CONTRATO DE MUTUO ACUERDO EN NOVIEMBRE 2005',0.16,57840.32 ,67094.77 ,'4/30/2004','REDACCION DEL PROYECTO DE OBRA Y ESTUDIO DE SEGURIDAD Y SALUD PARA LA OBRA DE REFORMA Y REORDENACION DEL AREA DE HOSPITALIZACION Y MEDIDAS CONTRAINCENDIOS DEL HOSPITAL UNIVERSITARIO "VIRGEN DE LA VICTORIA" DE MALAGA Y LA DIRECCION DE OBRA');
INSERT INTO CONTRATO VALUES(6,2,6,'Kike Pelado Rodriguez','102153','ARQSevilla','Tener en cuenta la segunda parte del contrato',0.16,2494.20 ,2893.27 ,'3/4/1998',NULL);
INSERT INTO CONTRATO VALUES(7,3,7,'Juan Alberto Nu�ez Perejon','HS01078/01','ARQSevilla',NULL,0.16,10337.41 ,11991.39 ,'11/26/2001','COLABORACION PARA LA REDACCION Y EJECUCION DEL FUTURO CONVENIO URBANISTICO ENTRE IMPROASA Y EL EXCMO. AYUNTAMIENTO DE ARAHAL');
INSERT INTO CONTRATO VALUES(8,4,8,'Marcos de la Rosa Vizcaino','CC0034/98','ARQSevilla','A revisar la nueva edicion del convenio',0.16,7976.29 ,9252.50 ,'6/1/2004',NULL);
INSERT INTO CONTRATO VALUES(9,5,9,'Kike Pelado Rodriguez','CM 244/98','ARQSevilla',NULL,0.16,10336.37 ,11990.19 ,'3/21/2005','REDACCION DE PROYECTO HOSPITAL CAMPUS DE LA SALUD DE GRANADA');
INSERT INTO CONTRATO VALUES(10,1,10,'Kike Pelado Rodriguez','CM 169/98','ARQSevilla','SE RESCINDE EL CONTRATO DE MUTUO ACUERDO EN NOVIEMBRE 2005',0.16,57840.32 ,67094.77 ,'4/30/2004','REDACCION DEL PROYECTO DE OBRA Y ESTUDIO DE SEGURIDAD Y SALUD PARA LA OBRA DE REFORMA Y REORDENACION DEL AREA DE HOSPITALIZACION Y MEDIDAS CONTRAINCENDIOS DEL HOSPITAL UNIVERSITARIO "VIRGEN DE LA VICTORIA" DE MALAGA Y LA DIRECCION DE OBRA');
INSERT INTO CONTRATO VALUES(12,3,11,'Kike Pelado Rodriguez','102153','ARQSevilla','Tener en cuenta la segunda parte del contrato',0.16,2494.20 ,2893.27 ,'3/4/1998',NULL);
INSERT INTO CONTRATO VALUES(13,4,12,'Juan Alberto Nu�ez Perejon','HS01078/01','ARQSevilla',NULL,0.16,10337.41 ,11991.39 ,'11/26/2001','COLABORACION PARA LA REDACCION Y EJECUCION DEL FUTURO CONVENIO URBANISTICO ENTRE IMPROASA Y EL EXCMO. AYUNTAMIENTO DE ARAHAL');
INSERT INTO CONTRATO VALUES(14,5,13,'Marcos de la Rosa Vizcaino','CC0034/98','ARQSevilla','A revisar la nueva edicion del convenio',0.16,7976.29 ,9252.50 ,'6/1/2004',NULL);
INSERT INTO CONTRATO VALUES(15,1,14,'Kike Pelado Rodriguez','CM 244/98','ARQSevilla',NULL,0.16,10336.37 ,11990.19 ,'3/21/2005','REDACCION DE PROYECTO HOSPITAL CAMPUS DE LA SALUD DE GRANADA');
INSERT INTO CONTRATO VALUES(16,2,15,'Kike Pelado Rodriguez','CM 169/98','ARQSevilla','SE RESCINDE EL CONTRATO DE MUTUO ACUERDO EN NOVIEMBRE 2005',0.16,57840.32 ,67094.77 ,'4/30/2004','REDACCION DEL PROYECTO DE OBRA Y ESTUDIO DE SEGURIDAD Y SALUD PARA LA OBRA DE REFORMA Y REORDENACION DEL AREA DE HOSPITALIZACION Y MEDIDAS CONTRAINCENDIOS DEL HOSPITAL UNIVERSITARIO "VIRGEN DE LA VICTORIA" DE MALAGA Y LA DIRECCION DE OBRA');
INSERT INTO CONTRATO VALUES(17,4,16,'Kike Pelado Rodriguez','102153','ARQSevilla','Tener en cuenta la segunda parte del contrato',0.16,2494.20 ,2893.27 ,'3/4/1998',NULL);
INSERT INTO CONTRATO VALUES(18,5,17,'Juan Alberto Nu�ez Perejon','HS01078/01','ARQSevilla',NULL,0.16,10337.41 ,11991.39 ,'11/26/2001','COLABORACION PARA LA REDACCION Y EJECUCION DEL FUTURO CONVENIO URBANISTICO ENTRE IMPROASA Y EL EXCMO. AYUNTAMIENTO DE ARAHAL');
INSERT INTO CONTRATO VALUES(19,1,18,'Marcos de la Rosa Vizcaino','CC0034/98','ARQSevilla','A revisar la nueva edicion del convenio',0.16,7976.29 ,9252.50 ,'6/1/2004',NULL);
INSERT INTO CONTRATO VALUES(20,2,19,'Kike Pelado Rodriguez','CM 244/98','ARQSevilla',NULL,0.16,10336.37 ,11990.19 ,'3/21/2005','REDACCION DE PROYECTO HOSPITAL CAMPUS DE LA SALUD DE GRANADA');
INSERT INTO CONTRATO VALUES(21,3,20,'Kike Pelado Rodriguez','CM 169/98','ARQSevilla','SE RESCINDE EL CONTRATO DE MUTUO ACUERDO EN NOVIEMBRE 2005',0.16,57840.32 ,67094.77 ,'4/30/2004','REDACCION DEL PROYECTO DE OBRA Y ESTUDIO DE SEGURIDAD Y SALUD PARA LA OBRA DE REFORMA Y REORDENACION DEL AREA DE HOSPITALIZACION Y MEDIDAS CONTRAINCENDIOS DEL HOSPITAL UNIVERSITARIO "VIRGEN DE LA VICTORIA" DE MALAGA Y LA DIRECCION DE OBRA');
INSERT INTO CONTRATO VALUES(22,5,21,'Kike Pelado Rodriguez','102153','ARQSevilla','Tener en cuenta la segunda parte del contrato',0.16,2494.20 ,2893.27 ,'3/4/1998',NULL);
INSERT INTO CONTRATO VALUES(23,1,22,'Juan Alberto Nu�ez
Perejon', 'HS01078/01','ARQSevilla',NULL,0.16,10337.41 ,11991.39 ,'11/26/2001','COLABORACION PARA LA REDACCION Y EJECUCION DEL FUTURO CONVENIO URBANISTICO ENTRE IMPROASA Y EL EXCMO. AYUNTAMIENTO DE ARAHAL');
INSERT INTO CONTRATO VALUES(24,2,23,'Marcos de la Rosa Vizcaino','CC0034/98','ARQSevilla','A revisar la nueva edicion del convenio',0.16,7976.29 ,9252.50 ,'6/1/2004',NULL);
INSERT INTO CONTRATO VALUES(25,3,24,'Kike Pelado Rodriguez','CM 244/98','ARQSevilla',NULL,0.16,10336.37 ,11990.19 ,'3/21/2005','REDACCION DE PROYECTO HOSPITAL CAMPUS DE LA SALUD DE GRANADA');
INSERT INTO CONTRATO VALUES(26,4,25,'Kike Pelado Rodriguez','CM 169/98','ARQSevilla','SE RESCINDE EL CONTRATO DE MUTUO ACUERDO EN NOVIEMBRE 2005',0.16,57840.32 ,67094.77 ,'4/30/2004','REDACCION DEL PROYECTO DE OBRA Y ESTUDIO DE SEGURIDAD Y SALUD PARA LA OBRA DE REFORMA Y REORDENACION DEL AREA DE HOSPITALIZACION Y MEDIDAS CONTRAINCENDIOS DEL HOSPITAL UNIVERSITARIO "VIRGEN DE LA VICTORIA" DE MALAGA Y LA DIRECCION DE OBRA');

INSERT INTO FACTURA VALUES(1,1,'3/8/1998','PAGO 2 CONSULTAS AXARQUIA','5/5/1998');
INSERT INTO FACTURA VALUES(2,2,'11/29/2001','Asistencia Tecnica para la Redacci�n del Plan Funcional de la nueva escuela de Turismo y Hosteleria de la Provincia de Cadiz .(FEDER.Proyecto Cultur-Cad. P.O.I. de Andalucia 2000-2006)','3/21/2001');
INSERT INTO FACTURA VALUES(3,3,'6/6/2004','Informe sobre la idoneidad tecnica de os edificios para la Consejeria de Innovacion, Ciencia y Empresa','6/17/2004');
INSERT INTO FACTURA VALUES(4,4,'5/28/2005','Proyecto y Direcci�n de las Obras de una Resonancia Magnetica en el Hospital Universitario Virgen de las Nieves de Granada','4/5/2005');
INSERT INTO FACTURA VALUES(5,5,'4/5/2004','COLABORACION EN PROYECTOS REALIZADOS','5/23/2004');
INSERT INTO FACTURA VALUES(6,1,'3/8/1998','PAGO 2 CONSULTAS AXARQUIA','5/5/1998');
INSERT INTO FACTURA VALUES(7,2,'11/29/2001','Asistencia Tecnica para la Redacci�n del Plan Funcional de la nueva escuela de Turismo y Hosteleria de la Provincia de Cadiz .(FEDER.Proyecto Cultur-Cad. P.O.I. de Andalucia 2000-2006)','3/21/2001');
INSERT INTO FACTURA VALUES(8,3,'6/6/2004','Informe sobre la idoneidad tecnica de os edificios para la Consejeria de Innovacion, Ciencia y Empresa','6/17/2004');
INSERT INTO FACTURA VALUES(9,4,'5/28/2005','Proyecto y Direcci�n de las Obras de una Resonancia Magnetica en el Hospital Universitario Virgen de las Nieves de Granada','4/5/2005');
INSERT INTO FACTURA VALUES(10,5,'4/5/2004','COLABORACION EN PROYECTOS REALIZADOS','5/23/2004');
INSERT INTO FACTURA VALUES(11,1,'3/8/1998','PAGO 2 CONSULTAS AXARQUIA','5/5/1998');
INSERT INTO FACTURA VALUES(12,2,'11/29/2001','Asistencia Tecnica para la Redacci�n del Plan Funcional de la nueva escuela de Turismo y Hosteleria de la Provincia de Cadiz .(FEDER.Proyecto Cultur-Cad. P.O.I. de Andalucia 2000-2006)','3/21/2001');
INSERT INTO FACTURA VALUES(13,3,'6/6/2004','Informe sobre la idoneidad tecnica de os edificios para la Consejeria de Innovacion, Ciencia y Empresa','6/17/2004');
INSERT INTO FACTURA VALUES(14,4,'5/28/2005','Proyecto y Direcci�n de las Obras de una Resonancia Magnetica en el Hospital Universitario Virgen de las Nieves de Granada','4/5/2005');
INSERT INTO FACTURA VALUES(15,5,'4/5/2004','COLABORACION EN PROYECTOS REALIZADOS','5/23/2004');
INSERT INTO FACTURA VALUES(16,1,'3/8/1998','PAGO 2 CONSULTAS AXARQUIA','5/5/1998');
INSERT INTO FACTURA VALUES(17,2,'11/29/2001','Asistencia Tecnica para la Redacci�n del Plan Funcional de la nueva escuela de Turismo y Hosteleria de la Provincia de Cadiz .(FEDER.Proyecto Cultur-Cad. P.O.I. de Andalucia 2000-2006)','3/21/2001');
INSERT INTO FACTURA VALUES(18,3,'6/6/2004','Informe sobre la idoneidad tecnica de os edificios para la Consejeria de Innovacion, Ciencia y Empresa','6/17/2004');
INSERT INTO FACTURA VALUES(19,4,'5/28/2005','Proyecto y Direcci�n de las Obras de una Resonancia Magnetica en el Hospital Universitario Virgen de las Nieves de Granada','4/5/2005');
INSERT INTO FACTURA VALUES(20,5,'4/5/2004','COLABORACION EN PROYECTOS REALIZADOS','5/23/2004');
INSERT INTO FACTURA VALUES(21,1,'3/8/1998','PAGO 2 CONSULTAS AXARQUIA','5/5/1998');
INSERT INTO FACTURA VALUES(22,2,'11/29/2001','Asistencia Tecnica para la Redacci�n del Plan Funcional de la nueva escuela de Turismo y Hosteleria de la Provincia de Cadiz .(FEDER.Proyecto Cultur-Cad. P.O.I. de Andalucia 2000-2006)','3/21/2001');
INSERT INTO FACTURA VALUES(23,3,'6/6/2004','Informe sobre la idoneidad tecnica de os edificios para la Consejeria de Innovacion, Ciencia y Empresa','6/17/2004');
INSERT INTO FACTURA VALUES(24,4,'5/28/2005','Proyecto y Direcci�n de las Obras de una Resonancia Magnetica en el Hospital Universitario Virgen de las Nieves de Granada','4/5/2005');
INSERT INTO FACTURA VALUES(25,5,'4/5/2004','COLABORACION EN PROYECTOS REALIZADOS','5/23/2004');


INSERT INTO DETALLES VALUES(1,1,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(2,2,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(3,3,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(4,4,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(5,5,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(2,1,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(3,2,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(4,3,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(5,4,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(1,5,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(3,1,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(4,2,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(5,3,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(1,4,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(2,5,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(4,1,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(5,2,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(1,3,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(2,4,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(3,5,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(5,1,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(1,2,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(2,3,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(3,4,0,0,0.21,'Euros',0,0);
INSERT INTO DETALLES VALUES(4,5,0,0,0.21,'Euros',0,0);

ALTER TABLE DETALLES ADD CONSTRAINT FK_DETALLES15 FOREIGN KEY (IdFactura) REFERENCES FACTURA (IdFactura) ;
ALTER TABLE CONTRATO ADD CONSTRAINT FK_CONTRATO16 FOREIGN KEY (IdCliente) REFERENCES CLIENTE (IdCliente) ;
ALTER TABLE CONTRATO ADD CONSTRAINT FK_CONTRATO17 FOREIGN KEY (IdCentro) REFERENCES CENTRO (IdCentro) ;
ALTER TABLE CENTRO ADD CONSTRAINT FK_CENTRO18 FOREIGN KEY (Centro_referencia) REFERENCES CENTRO (IdCentro) ;
